import polygonClipping from 'polygon-clipping';
import {area} from './geometry.js';

export const PAPER_GAP = .032;
export function footprint(p) {
  const c=Math.cos(p.rot||0),s=Math.sin(p.rot||0),flip=Math.cos(p.turning??p.flip??0);
  return p.poly.map(r=>r.map(([x,y])=>[p.x+flip*(c*x-s*y),p.y+s*x+c*y]));
}
export function overlaps(a,b) {
  if(Math.abs(Math.cos(a.turning??a.flip??0))<.001||Math.abs(Math.cos(b.turning??b.flip??0))<.001)return false;
  const A=footprint(a),B=footprint(b);
  const bounds=p=>[Math.min(...p[0].map(v=>v[0])),Math.max(...p[0].map(v=>v[0])),Math.min(...p[0].map(v=>v[1])),Math.max(...p[0].map(v=>v[1]))];
  const x=bounds(A),y=bounds(B);
  if(x[0]>=y[1]||y[0]>=x[1]||x[2]>=y[3]||y[2]>=x[3])return false;
  return polygonClipping.intersection(A,B).some(p=>area(p)>1e-7);
}
export function surfaceRange(p,positions) {
  const angle=p.turning??p.flip??0,sz=Math.sin(angle),cz=Math.cos(angle),c=Math.cos(p.rot||0),s=Math.sin(p.rot||0);
  let low=0,high=0;
  if(positions)for(let i=0;i<positions.length;i+=3){let z=sz*(c*positions[i]-s*positions[i+1])+cz*positions[i+2];low=Math.min(low,z);high=Math.max(high,z)}
  const glue=(p.glue?.length ? .064 : 0);
  low-=cz<0?glue:0;high+=cz>=0?glue:0;
  return {low,high};
}
// Raise a whole bonded group by the same amount, preserving its layer offsets.
export function restingBase(moving,others,range=()=>({low:0,high:0}),mat=null) {
  const base=Math.min(...moving.map(p=>p.z));let result=.075;
  const board=mat&&{x:mat.x,y:mat.y,poly:[[[-2.85,-2.5],[2.85,-2.5],[2.85,2.5],[-2.85,2.5],[-2.85,-2.5]]]};
  for(const p of moving){let offset=p.z-base,low=range(p).low;result=Math.max(result,.075-offset-low);
    if(board&&overlaps(p,board))result=Math.max(result,.17-offset-low);
    for(const q of others)if(overlaps(p,q))result=Math.max(result,q.z+range(q).high+PAPER_GAP-offset-low);
  }
  return result;
}
