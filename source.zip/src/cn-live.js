import {initialSlugs} from './cn-source-catalogue.js';
import {read,write} from './storage.js';
export const cnOrigins=['https://api.blog.yaoxi.cloud','https://blog.yaoxi.wiki'];
const normalizeSlug=s=>String(s||'').replace(/\.md$/i,'');
const validSlug=s=>/^[\p{L}\p{N}_-]{1,160}$/u.test(s);
export function articleGenre(data){const text=[data.title,data.category,...(data.tags||[])].join(' ');if(/技术|开发|架构|修复|\bAPI\b|\bAI\b|Astro|Cloud|前端|服务器|数据库|Umami|CDN|域名|云服务|工作流|博客系统|个人主页/i.test(text))return '技术';if(/小说|文学|除名|青春|概率之外|第一章/.test(text))return '文学';if(/心理|情绪|身心|家庭|边界|沟通|代际|精神|代偿/.test(text))return '心理与关系';if(/历史|近代史|文化|二次元|动漫|ACG|毕业|纪事|除夕/i.test(text))return '文化与历史';if(/生活|日常|母亲|成长|坚持|复利/.test(text))return '生活';return '杂谈'}
export function chineseArticle(data,slug){
 if(data.draft||data.encrypted||typeof data.text!=='string'||data.text.length<120||!data.title)return null;
 if(/转载|翻译/.test(data.category||''))return null;
 if((data.text.match(/[\u3400-\u9fff]/g)||[]).length<80)return null;
 return {articleId:'yaoxi:'+slug,title:data.title,text:data.text.slice(0,2600),genre:articleGenre(data),source:'https://blog.yaoxi.wiki/posts/'+encodeURIComponent(slug)+'/',author:'瑶曦 · Yaoxi Blog',license:'CC BY-NC-SA 4.0 · 非商业 · 节选重排',licenseUrl:'https://creativecommons.org/licenses/by-nc-sa/4.0/',licenseEvidence:'https://api.blog.yaoxi.cloud/posts/blog-api-guide/'};
}
async function requestArticle(slug){
 for(const origin of cnOrigins){try{const r=await fetch(origin+'/api/posts/'+encodeURIComponent(slug)+'.json',{mode:'cors',credentials:'omit',referrerPolicy:'no-referrer',cache:'no-store',signal:AbortSignal.timeout(5500)});if(r.status===404)return null;if(!r.ok)throw Error('HTTP '+r.status);return await r.json()}catch{}}
 throw Error('中文文章接口暂未连通');
}
// Randomness and persistent issuance history are owned by the caller.
export async function liveChinese(history,shuffle,onStatus){
 const known=new Set(history),saved=await read('state','cn-live-articles-v1')||[],extra=await read('state','cn-live-slugs-v1')||[];
 const slugs=shuffle([...new Set([...initialSlugs,...extra])]).filter(s=>validSlug(s)&&!known.has('id:yaoxi:'+s));
 const articles=[],discovered=new Set(extra);let reachable=false,failures=0;
 // At most 12 articles, with three simultaneous requests; stop after a failed batch.
 for(let offset=0;offset<Math.min(12,slugs.length);offset+=3){
  onStatus('正在直连中文文章接口，寻找没取过的文章…');
  const results=await Promise.allSettled(slugs.slice(offset,offset+3).map(async slug=>({slug,data:await requestArticle(slug)})));
  let succeeded=0;
  for(const result of results){if(result.status!=='fulfilled'){failures++;continue}reachable=true;succeeded++;const {slug,data}=result.value;if(!data)continue;for(const neighbour of [data.prev?.slug,data.next?.slug]){const normalized=normalizeSlug(neighbour);if(validSlug(normalized))discovered.add(normalized)}const article=chineseArticle(data,slug);if(article)articles.push(article)}
  if(articles.length>=10||!succeeded)break;
 }
 const cache=new Map(saved.map(article=>[article.articleId,article]));articles.forEach(article=>cache.set(article.articleId,article));
 await write('state','cn-live-articles-v1',[...cache.values()]);await write('state','cn-live-slugs-v1',[...discovered].slice(-500));
 return {articles,cached:shuffle(saved),reachable,failures};
}
