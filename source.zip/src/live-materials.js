import {chineseArticle} from './cn-live.js';
import {initialSlugs} from './cn-source-catalogue.js';
const sites={
 'www.waterwater.moe':{id:'water',body:'.markdown-content'},
 'ikangjia.cn':{id:'ikangjia',body:'article.prose'},
 'tuoruipeng.com':{id:'tuorui',body:'.prose'}
};
const licence='https://creativecommons.org/licenses/by-nc-sa/4.0/';
export function parseLiveArticle(html,candidate){
 const host=new URL(candidate.source).hostname,site=sites[host];if(!site)return null;
 // A template is inert: article scripts, embeds and images never enter the page.
 const template=document.createElement('template');template.innerHTML=html;
 const root=template.content,links=[...root.querySelectorAll('a[href]')].map(a=>a.getAttribute('href')).filter(h=>/creativecommons\.org\/licenses\//.test(h));
 if(links.some(h=>!h.includes('/by-nc-sa/4.0')))return null;
 if(!links.some(h=>h.includes('/by-nc-sa/4.0'))&&host!=='tuoruipeng.com')return null;
 const body=root.querySelector(site.body);if(!body)return null;
 const title=root.querySelector('meta[property="og:title"]')?.getAttribute('content')||[...root.querySelectorAll('main h1')].at(-1)?.textContent?.trim()||candidate.title;
 if(/转载|翻译|版权|隐私|免责声明|友链|友情链接|建站|站点公告|更新日志|博客搭建|API 文档/.test(title))return null;
 body.querySelectorAll('script,style,nav,footer,header,.license-container,.license,.post-meta,.toc,pre,code,blockquote,figure,img,button,svg,iframe,.anchor').forEach(e=>e.remove());
 body.querySelectorAll('p,h1,h2,h3,h4,li,section,br').forEach(e=>e.append('\n'));
 const text=body.textContent.replace(/[\t \u00a0]+/g,' ').replace(/\n\s*\n+/g,'\n\n').trim();
 if((text.match(/[\u3400-\u9fff]/g)||[]).length<120)return null;
 return {...candidate,title,text:text.slice(0,5000),licenseUrl:licence,fetchedAt:Date.now()};
}
function allowed(a){try{return a.licenseUrl===licence&&sites[new URL(a.source).hostname]&&new URL(a.source).protocol==='https:'}catch{return false}}
export async function fetchLiveArticles(fallback,history,shuffle,onStatus,{timeout=9000}={}){
 const signal=AbortSignal.timeout(timeout),known=new Set(history);let current=[];
 onStatus('优先实时取文，备用的 100 篇已就绪…');
 // The hourly catalogue extends the live source list; a missing catalogue is harmless.
 try{const r=await fetch('./materials.json',{cache:'no-store',signal:AbortSignal.any([signal,AbortSignal.timeout(1800)])});if(r.ok){const p=await r.json();if(Array.isArray(p.articles))current=p.articles}}catch{}
 const catalog=new Map([...fallback,...current].filter(allowed).map(a=>[a.articleId,a]));
 const buckets=Object.values(sites).map(s=>shuffle([...catalog.values()].filter(a=>a.articleId?.startsWith(s.id+':')&&!known.has('id:'+a.articleId))));
 buckets.push(shuffle(initialSlugs.filter(s=>!known.has('id:yaoxi:'+s)).map(slug=>({slug,articleId:'yaoxi:'+slug}))));
 const queue=[];for(let i=0;i<12;i++)for(const bucket of shuffle(buckets)){if(bucket[i])queue.push(bucket[i])}
 const articles=[];let cursor=0,attempted=0,reachable=false;
 // Six workers share one nine-second deadline, rather than waiting once per article.
 async function worker(){while(cursor<Math.min(24,queue.length)&&articles.length<12&&!signal.aborted){
  const candidate=queue[cursor++];attempted++;
  try{const url=candidate.slug?'https://api.blog.yaoxi.cloud/api/posts/'+encodeURIComponent(candidate.slug)+'.json':candidate.source;
   const r=await fetch(url,{mode:'cors',credentials:'omit',referrerPolicy:'no-referrer',cache:'no-store',signal});if(!r.ok)continue;reachable=true;
   const a=candidate.slug?chineseArticle(await r.json(),candidate.slug):parseLiveArticle(await r.text(),candidate);if(a)articles.push(a);
  }catch{}
 }}
 await Promise.all(Array.from({length:6},worker));return {articles,attempted,reachable};
}
