export function exportTerms(sources){
 const nc=sources.some(s=>s.licenseUrl?.includes('/by-nc-sa/')),sa=sources.some(s=>s.licenseUrl?.includes('/by-sa/'));
 if(nc&&sa)return {allowed:false,message:'作品同时使用了两种不兼容的相同方式共享许可，请把旧维基素材与中文博客素材分开导出。'};
 return {allowed:true,line:nc?'文字节选与拼贴：署名—非商业性使用—相同方式共享 4.0 · https://creativecommons.org/licenses/by-nc-sa/4.0/':sa?'文字改编与拼贴：署名—相同方式共享 4.0 · https://creativecommons.org/licenses/by-sa/4.0/':''};
}
