import {takeVariedUnseen} from './article-history.js';
// A persisted shuffled bag: repeats are allowed only after the bag is exhausted.
export function drawFallback(prepared,saved,excluded,need,shuffle){
 const byId=new Map(prepared.map(p=>[p.article.articleId,p])),all=[...byId.keys()];
 let remaining=saved?.remaining? [...new Set(saved.remaining)].filter(id=>byId.has(id)):shuffle(all);
 let cycle=saved?.cycle||1;const last=new Set(saved?.lastBook||[]),chosen=[],keys=[...excluded];
 while(chosen.length<need){
  if(!remaining.length){remaining=shuffle(all);cycle++}
  const ordered=remaining.map(id=>byId.get(id));
  const preferred=ordered.filter(p=>!last.has(p.article.articleId));
  let pick=takeVariedUnseen(preferred,keys,need-chosen.length).selected;
  if(!pick.length)pick=takeVariedUnseen(ordered,keys,need-chosen.length).selected;
  if(!pick.length){remaining=[];if(all.every(id=>chosen.some(a=>a.articleId===id)))throw Error('备用素材不够');continue}
  const picked=new Set(pick.map(a=>a.articleId));remaining=remaining.filter(id=>!picked.has(id));
  for(const a of pick){chosen.push(a);keys.push(...byId.get(a.articleId).keys)}
 }
 return {selected:chosen,deck:{remaining,cycle,lastBook:chosen.map(a=>a.articleId)}};
}
