// Only bound pages go on the shelf; cut-out material stays on the table.
export function switchBook(state, activeId) {
  state.activeBook = activeId;
  for (const book of state.books) {
    book.pages ||= [];
    if (book.id === activeId) {
      state.pieces.push(...book.pages);
      book.pages = [];
    } else {
      book.pages.push(...state.pieces.filter(p => p.book === book.id));
      state.pieces = state.pieces.filter(p => p.book !== book.id);
    }
  }
}
