const normalize=s=>String(s||'').normalize('NFKC').toLowerCase().replace(/[\s\p{P}]/gu,'');
export async function articleKeys(article){
 const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(normalize(article.text)));
 const keys=['text:'+Array.from(new Uint8Array(digest),n=>n.toString(16).padStart(2,'0')).join('')];
 if(article.title)keys.push('title:'+normalize(article.title));
 if(article.articleId)keys.push('id:'+article.articleId);
 else if(article.source?.includes('wikipedia.org/'))keys.push('url:'+article.source);
 return keys;
}
export async function prepareArticles(articles){return Promise.all(articles.filter(a=>a?.text?.trim()).map(async article=>({article,keys:await articleKeys(article)})))}
export function takeUnseen(prepared,history=[],limit=10){
 const seen=new Set(history),selected=[];
 for(const item of prepared){if(item.keys.some(key=>seen.has(key)))continue;selected.push(item.article);item.keys.forEach(key=>seen.add(key));if(selected.length>=limit)break}
 return {selected,history:[...seen]};
}
export function takeVariedUnseen(prepared,history=[],limit=10){
 const eligible=new Set(takeUnseen(prepared,history,Infinity).selected),items=prepared.filter(p=>eligible.has(p.article)),picked=[],genres=new Set();let technical=0;
 function add(item){if(picked.includes(item))return;if(item.article.genre==='技术'&&technical>=2)return;picked.push(item);if(item.article.genre==='技术')technical++;genres.add(item.article.genre||'生活')}
 // Include different authors before filling subject slots.
 const authors=new Set();for(const item of items){const author=item.article.author;if(author&&!authors.has(author)){add(item);authors.add(author)}if(picked.length>=limit)break}
 // Give each available subject a turn before filling remaining pages.
 for(const item of items){if(picked.length>=limit)break;if(!genres.has(item.article.genre||'生活'))add(item)}
 for(const item of items){if(picked.length>=limit)break;add(item)}
 for(const item of items){if(picked.length>=limit)break;if(!picked.includes(item))picked.push(item)}
 return takeUnseen(picked,history,limit);
}
