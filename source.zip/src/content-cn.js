import {imageAsset,update,read} from './storage.js';
import {prepareArticles,takeVariedUnseen,takeUnseen} from './article-history.js';
import {fetchLiveArticles} from './live-materials.js';
import fallbackArticles from './fallback-articles.json' with {type:'json'};
import artwork from './artwork.json' with {type:'json'};
const historyKey='issued-articles-v1';
export const fallbackCount=fallbackArticles.length;
export const shuffle=(input,random=Math.random)=>{const a=[...input];for(let i=a.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
export async function rememberArticles(articles){const old=await prepareArticles(articles);return update('state',historyKey,history=>({value:[...new Set([...(history||[]),...old.flatMap(a=>a.keys)])]}))}
function notify(liveCount,fallbackCount){if(typeof dispatchEvent==='function')dispatchEvent(new CustomEvent('material-pool',{detail:{liveCount,fallbackCount,total:100}}))}
export async function getMagazine(onStatus,existing=[],{liveFetch=fetchLiveArticles}={}){
 await rememberArticles(existing);const history=await read('state',historyKey)||[];
 let online;try{online=await liveFetch(fallbackArticles,history,shuffle,onStatus)}catch{online={articles:[]}}
 const livePrepared=await prepareArticles(online.articles||[]),fallbackPrepared=await prepareArticles(shuffle(fallbackArticles));
 const chosen=await update('state',historyKey,history=>{
  const fresh=takeVariedUnseen(livePrepared,history||[],10);
  // Past issuance does not exclude fallback text. Only avoid duplicates inside this book.
  const liveKeys=livePrepared.filter(p=>fresh.selected.includes(p.article)).flatMap(p=>p.keys);
  const backup=fresh.selected.length<10?takeVariedUnseen(fallbackPrepared,liveKeys,10-fresh.selected.length).selected:[];
  const selected=[...fresh.selected,...backup],fallbackKeys=fallbackPrepared.filter(p=>backup.includes(p.article)).flatMap(p=>p.keys);
  return {value:[...new Set([...fresh.history,...fallbackKeys])],result:{selected,liveCount:fresh.selected.length,fallbackCount:backup.length}};
 });
 if(chosen.selected.length!==10)throw Error('备用素材包不完整，请刷新网页。');
 const pictures=shuffle(artwork),pages=chosen.selected.map((text,i)=>{const art=pictures[i%pictures.length];return {...text,...art, fallbackImage:art.image,fallbackImageSource:art.imageSource,fallbackImageAuthor:art.imageAuthor,seed:Math.floor(Math.random()*1e8),layout:Math.floor(Math.random()*5)}});
 notify(chosen.liveCount,chosen.fallbackCount);
 const note=chosen.liveCount===10?'实时取文 10 篇':chosen.liveCount?'实时取文 '+chosen.liveCount+' 篇，备用补充 '+chosen.fallbackCount+' 篇':'实时取文未成功或没有未取过的新文 · 从内置 100 篇中随机取 10 篇（允许重复）';
 return {id:crypto.randomUUID(),created:Date.now(),pages,live:chosen.liveCount>0,liveCount:chosen.liveCount,fallbackCount:chosen.fallbackCount,note};
}
export {imageAsset};
