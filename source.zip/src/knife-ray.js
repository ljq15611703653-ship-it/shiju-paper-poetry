import {Matrix4,Plane,Ray,Vector3} from 'three';

// Preserve the mouse ray, then intersect each paper in its own local frame.
// Reusing table x/y at another height introduces parallax in an angled camera.
export function localCutPoint(sample,matrixWorld) {
  const inverse=new Matrix4().copy(matrixWorld).invert();
  const ray=new Ray(new Vector3().fromArray(sample.origin),new Vector3().fromArray(sample.direction)).applyMatrix4(inverse);
  return ray.intersectPlane(new Plane(new Vector3(0,0,1),0),new Vector3());
}
