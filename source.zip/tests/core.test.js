import test from 'node:test';
import assert from 'node:assert/strict';
import {rectangle,cutPolygon,area,triangulate,glueState,groupIds} from '../src/geometry.js';
import {PaperPhysics,stepGlue} from '../src/physics.js';
test('knife splits a sheet and the resulting piece can be cut again',()=>{let cuts=cutPolygon(rectangle(3,4),[[-2,0],[2,0]]);assert.equal(cuts.length,2);assert.ok(cuts.reduce((s,p)=>s+area(p),0)<12);let again=cutPolygon(cuts[0],[[0,-3],[0,3]]);assert.equal(again.length,2);assert.ok(again.every(p=>area(p)>0))});
test('closed cut makes a hole plus independent centre',()=>{let c=cutPolygon(rectangle(4,4),[[-1,-1],[1,-1],[1,1],[-1,1],[-1,-1]]);assert.equal(c.length,2);assert.ok(c.some(p=>p.length===2))});
test('drying is exactly 20 seconds, bonded groups remain connected',()=>{assert.equal(glueState(1000,20999).wet,true);assert.equal(glueState(1000,21000).wet,false);assert.deepEqual([...groupIds('a',[['a','b'],['b','c'],['d','e']])].sort(),['a','b','c'])});
function cloth(seed=4,contact=.8){let p={w:2,h:2,poly:rectangle(2,2),glue:[{x:.2,y:0,r:.12,born:1000,contact}],turns:0,old:.2};let c=new PaperPhysics(triangulate(p.poly,.3),p,seed);return [p,c]}
test('XPBD stays finite and responds locally to a pin',()=>{let [p,c]=cloth();p.pin={x:.8,y:.8,lift:.5,dx:0,dy:0};for(let i=0;i<80;i++)c.step(1/60,1000+i*16);assert.ok([...c.pos].every(Number.isFinite));assert.ok(c.sample(.8,.8)[2]>c.sample(-.8,-.8)[2]+.1)});
test('different fibre seeds and bonding times produce different dry sheets',()=>{let [p,a]=cloth(4,.9),[q,b]=cloth(8,.2);for(let i=0;i<180;i++){a.step(1/60,18000+i*20);b.step(1/60,18000+i*20)}let delta=a.pos.reduce((s,v,i)=>s+Math.abs(v-b.pos[i]),0);assert.ok(delta>.001);assert.ok(a.shrink.some(v=>v>0));assert.ok([...a.pos,...b.pos].every(Number.isFinite))});
test('fluid flows down a lifted sheet; cured glue no longer flows',()=>{let [p,c]=cloth();p.glue=[{x:.1,y:0,r:.08,born:1000},{x:.15,y:0,r:.08,born:1000}];p.turning=1;let x=p.glue[0].x;for(let i=0;i<100;i++)stepGlue(p,c,1/60,2000+i*16);assert.notEqual(p.glue[0].x,x);let before=structuredClone(p.glue);stepGlue(p,c,1/60,30000);assert.deepEqual(p.glue,before)});
