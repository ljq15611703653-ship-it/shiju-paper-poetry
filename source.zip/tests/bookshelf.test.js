import test from 'node:test';
import assert from 'node:assert/strict';
import {switchBook} from '../src/bookshelf.js';
test('shelf swap and persistence preserve cuts, flip and detached pieces',()=>{
 let page={id:'p',book:'a',poly:[[[0,0],[1,0],[0,1]]],flip:Math.PI,turns:28,physics:{pos:[1,2,3]}};
 let s={books:[{id:'a'},{id:'b'}],pieces:[page,{id:'q',book:'b'},{id:'scrap',book:null}],basket:[]};
 switchBook(s,'b');assert.deepEqual(s.pieces.map(p=>p.id),['q','scrap']);assert.deepEqual(s.books[0].pages,[page]);
 s=JSON.parse(JSON.stringify(s));switchBook(s,'a');assert.deepEqual(s.pieces.map(p=>p.id),['scrap','p']);assert.deepEqual(s.pieces[1],page);
 switchBook(s,'a');assert.equal(s.pieces.length,2);assert.equal(s.books[1].pages.length,1);
});
