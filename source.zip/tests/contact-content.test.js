import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {rectangle} from '../src/geometry.js';
import {overlaps,restingBase,surfaceRange,PAPER_GAP} from '../src/paper-contact.js';
import {getMagazine} from '../src/content-cn.js';
const sheet=(x=0,y=0,z=.1)=>({x,y,z,rot:0,flip:0,poly:rectangle(2,2),glue:[]});
test('corner overlap supports a sheet whose centre is outside the lower sheet',()=>{
 const bottom=sheet(),top=sheet(1.8,1.8);
 assert.ok(overlaps(top,bottom));assert.ok(restingBase([top],[bottom])>=bottom.z+PAPER_GAP);
 assert.equal(overlaps(sheet(2.1,2.1),bottom),false);
});
test('holes, rotation and flipped pages produce the correct contact footprints',()=>{
 const frame=sheet();frame.poly=[...rectangle(4,4),...rectangle(2,2)];
 const small=sheet();small.poly=rectangle(.5,.5);assert.equal(overlaps(frame,small),false);
 const turned=sheet(2.2);turned.rot=Math.PI/4;assert.ok(overlaps(turned,sheet()));
 const asym=sheet();asym.poly=[[[0,0],[2,0],[2,1],[0,1],[0,0]]];asym.flip=Math.PI;
 assert.ok(overlaps(asym,sheet(-1)));assert.equal(overlaps(asym,sheet(3)),false);
});
test('glue film and wrinkles are included in the support height',()=>{
 const bottom=sheet(),top=sheet();bottom.glue=[{x:0,y:0}];
 const heights=new Map([[bottom,[0,0,.12]],[top,[0,0,0]]]);
 const range=p=>surfaceRange(p,heights.get(p));
 assert.ok(restingBase([top],[bottom],range)>=.1+.12+.064+PAPER_GAP-1e-9);
});
test('group support considers every fragment and keeps layer offsets without height drift',()=>{
 const a=sheet(0),b=sheet(3,0,.14),under=sheet(4.8,0,.3),group=[a,b];
 const base=restingBase(group,[under]);assert.ok(Math.abs(base-(.3+PAPER_GAP-.04))<1e-9);
 for(const p of group)p.z+=base-.1;
 assert.ok(Math.abs(restingBase(group,[under])-base)<1e-9);
 const mat={x:0,y:0};assert.ok(restingBase([sheet(3.7) ],[],undefined,mat)>=.17);
});
test('offline magazines contain ten distinct contemporary CC0 texts, never ancient fallback',async()=>{
 const original=globalThis.fetch,seed=JSON.parse(fs.readFileSync(new URL('../dist/seed.json',import.meta.url),'utf8'));
 globalThis.fetch=async url=>{if(url==='./seed.json')return {json:async()=>seed};throw Error('offline')};
 try{const mag=await getMagazine(()=>{});assert.equal(mag.pages.length,10);assert.equal(new Set(mag.pages.map(p=>p.title)).size,10);assert.ok(mag.pages.every(p=>p.author.includes('原创白话')&&p.text.length>200&&p.license.includes('CC0')));assert.equal(mag.live,false)}finally{globalThis.fetch=original}
});
