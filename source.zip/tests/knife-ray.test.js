import test from 'node:test';
import assert from 'node:assert/strict';
import {Matrix4,OrthographicCamera,Plane,Raycaster,Vector2,Vector3,Euler,Quaternion} from 'three';
import {localCutPoint} from '../src/knife-ray.js';

test('knife rays stay aligned with the mouse across heights, pan, zoom, rotation and flipped pages',()=>{
 for(const zoom of [.65,1,3])for(const pan of [0,2.3])for(const flip of [0,Math.PI])for(const z of [-.091,.109,.8]){
  const camera=new OrthographicCamera(-8,8,6,-6,.1,70);camera.up.set(0,0,1);camera.position.set(pan,-9,23);camera.lookAt(pan,0,0);camera.zoom=zoom;camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
  const matrix=new Matrix4().compose(new Vector3(-1,.4,z),new Quaternion().setFromEuler(new Euler(0,-flip,.43)),new Vector3(1,1,1));
  const local=new Vector3(.6,-.7,0),world=local.clone().applyMatrix4(matrix),screen=world.clone().project(camera),caster=new Raycaster();caster.setFromCamera(new Vector2(screen.x,screen.y),camera);
  const result=localCutPoint({origin:caster.ray.origin.toArray(),direction:caster.ray.direction.toArray()},matrix);
  assert.ok(result.distanceTo(local)<1e-9);const reprojection=result.applyMatrix4(matrix).project(camera);assert.ok(Math.hypot(reprojection.x-screen.x,reprojection.y-screen.y)<1e-9);
 }
});
test('each lower layer receives the same screen stroke rather than copied table coordinates',()=>{
 const camera=new OrthographicCamera(-8,8,6,-6,.1,70);camera.up.set(0,0,1);camera.position.set(0,-9,23);camera.lookAt(0,0,0);camera.updateMatrixWorld(true);
 const caster=new Raycaster();caster.setFromCamera(new Vector2(.1,.2),camera);const sample={origin:caster.ray.origin.toArray(),direction:caster.ray.direction.toArray()};
 const top=localCutPoint(sample,new Matrix4().makeTranslation(0,0,.6)),bottom=localCutPoint(sample,new Matrix4().makeTranslation(0,0,-.091));
 assert.ok(Math.abs(top.y-bottom.y)>.2);
 for(const [point,z] of [[top,.6],[bottom,-.091]]){point.z=z;const screen=point.project(camera);assert.ok(Math.abs(screen.x-.1)<1e-9);assert.ok(Math.abs(screen.y-.2)<1e-9)}
});
